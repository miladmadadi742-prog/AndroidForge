package com.ali.ali0734;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.nio.ByteBuffer;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class AimOverlayService extends Service {
    public static final String EXTRA_RESULT_CODE = "capture_result_code";
    public static final String EXTRA_RESULT_DATA = "capture_result_data";
    private static final String CHANNEL = "plato_live_capture";
    private static final int NOTIFICATION_ID = 71;
    private WindowManager wm;
    private LinearLayout panel;
    private GuideView guide;
    private WindowManager.LayoutParams panelParams, guideParams;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread captureThread;
    private Handler captureHandler;
    private ExecutorService analyzerExecutor;
    private final AtomicBoolean analyzing = new AtomicBoolean(false);
    private int screenWidth, screenHeight, screenDensity;
    private volatile BallAnalyzer.Result latest;
    private volatile String statusText = "در انتظار فریم...";

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private int overlayType() { return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE; }

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        analyzerExecutor = Executors.newSingleThreadExecutor();
        DisplayMetrics dm = new DisplayMetrics(); wm.getDefaultDisplay().getRealMetrics(dm);
        screenWidth = dm.widthPixels; screenHeight = dm.heightPixels; screenDensity = dm.densityDpi;
        createNotificationChannel();
        addGuide(); addPanel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !intent.hasExtra(EXTRA_RESULT_DATA)) { stopSelf(); return START_NOT_STICKY; }
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, buildNotification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(NOTIFICATION_ID, buildNotification());
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
        Intent data = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        try { startCapture(resultCode, data); }
        catch (Exception e) { statusText = "خطا در شروع ضبط صفحه"; if (guide != null) guide.postInvalidate(); stopSelf(); }
        return START_NOT_STICKY;
    }

    private void startCapture(int resultCode, Intent data) {
        MediaProjectionManager mgr = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mgr.getMediaProjection(resultCode, data);
        if (projection == null) throw new IllegalStateException("MediaProjection unavailable");
        captureThread = new HandlerThread("PlatoFrameCapture"); captureThread.start(); captureHandler = new Handler(captureThread.getLooper());
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        imageReader.setOnImageAvailableListener(reader -> {
            Image image = null;
            try {
                image = reader.acquireLatestImage();
                if (image == null || !analyzing.compareAndSet(false, true)) return;
                final Bitmap frame = imageToBitmap(image);
                analyzerExecutor.execute(() -> {
                    try {
                        int max = 900;
                        float scale = Math.min(1f, max / (float)Math.max(frame.getWidth(), frame.getHeight()));
                        Bitmap small = scale < 1f ? Bitmap.createScaledBitmap(frame, Math.max(1, Math.round(frame.getWidth()*scale)), Math.max(1, Math.round(frame.getHeight()*scale)), true) : frame;
                        BallAnalyzer.Result r = BallAnalyzer.analyze(small);
                        float backScale = 1f / scale;
                        r.scaleCoordinates(backScale);
                        latest = r; statusText = r.note;
                        if (guide != null) guide.postInvalidate();
                        if (small != frame) small.recycle();
                    } catch (Throwable t) { statusText = "تحلیل فریم ناموفق بود"; }
                    finally { if (!frame.isRecycled()) frame.recycle(); analyzing.set(false); }
                });
            } catch (Throwable ignored) { analyzing.set(false); }
            finally { if (image != null) image.close(); }
        }, captureHandler);
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stopSelf(); }
        }, captureHandler);
        virtualDisplay = projection.createVirtualDisplay("PlatoLiveCapture", screenWidth, screenHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.getSurface(), null, captureHandler);
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane plane = image.getPlanes()[0]; ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride(), rowStride = plane.getRowStride();
        int rowPadding = rowStride - pixelStride * image.getWidth();
        Bitmap padded = Bitmap.createBitmap(image.getWidth() + rowPadding / pixelStride, image.getHeight(), Bitmap.Config.ARGB_8888);
        buffer.rewind(); padded.copyPixelsFromBuffer(buffer);
        Bitmap out = Bitmap.createBitmap(padded, 0, 0, image.getWidth(), image.getHeight()); padded.recycle();
        return out;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "تشخیص زنده Plato", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification buildNotification() {
        Intent stop = new Intent(this, StopCaptureReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(this, 9, stop, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("ali0734 فعال است").setContentText("تحلیل زنده صفحه و خطوط راهنما در حال اجراست")
                .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause, "توقف", pi).build();
    }

    private TextView label(String s) { TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(12); t.setGravity(Gravity.CENTER); return t; }
    private Button button(String s, LinearLayout row, Runnable action) { Button b = new Button(this); b.setText(s); b.setTextSize(11); row.addView(b, new LinearLayout.LayoutParams(0, dp(40), 1)); b.setOnClickListener(v -> action.run()); return b; }
    private void addGuide() {
        guide = new GuideView();
        guideParams = new WindowManager.LayoutParams(-1, -1, overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT);
        guideParams.gravity = Gravity.TOP | Gravity.START; wm.addView(guide, guideParams);
    }
    private void addPanel() {
        panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(5), dp(3), dp(5), dp(3)); panel.setBackgroundColor(Color.argb(225, 18, 28, 38));
        TextView head = label("ALI0734 LIVE  •  تشخیص خودکار"); panel.addView(head, new LinearLayout.LayoutParams(-1, dp(30)));
        TextView state = label("در حال تحلیل فریم‌ها"); panel.addView(state, new LinearLayout.LayoutParams(-1, dp(26)));
        button("نمایش / مخفی خطوط", panel, () -> { if (guide != null) { guide.visible = !guide.visible; guide.invalidate(); } });
        button("توقف و بستن", panel, this::stopSelf);
        panelParams = new WindowManager.LayoutParams(dp(190), -2, overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.END; panelParams.x = dp(8); panelParams.y = dp(80);
        panel.setOnTouchListener(new View.OnTouchListener() { float sx, sy; int ox, oy; public boolean onTouch(View v, MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) { sx=e.getRawX(); sy=e.getRawY(); ox=panelParams.x; oy=panelParams.y; return true; }
            if (e.getAction() == MotionEvent.ACTION_MOVE) { panelParams.x=ox+(int)(sx-e.getRawX()); panelParams.y=oy+(int)(e.getRawY()-sy); wm.updateViewLayout(panel,panelParams); return true; }
            return true;
        }});
        wm.addView(panel, panelParams);
    }

    @Override public void onDestroy() {
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) {}
        try { if (imageReader != null) imageReader.close(); } catch (Exception ignored) {}
        try { if (projection != null) projection.stop(); } catch (Exception ignored) {}
        if (captureThread != null) captureThread.quitSafely();
        if (analyzerExecutor != null) analyzerExecutor.shutdownNow();
        if (wm != null) { try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) {} try { if (guide != null) wm.removeView(guide); } catch (Exception ignored) {} }
        stopForeground(true); super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }

    public static class StopCaptureReceiver extends BroadcastReceiver { @Override public void onReceive(Context c, Intent i) { c.stopService(new Intent(c, AimOverlayService.class)); } }

    private class GuideView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); boolean visible = true;
        GuideView() { super(AimOverlayService.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        private void line(Canvas c, float x1, float y1, float x2, float y2, int color, float width) { p.setColor(color); p.setStrokeWidth(dp(width)); p.setStyle(Paint.Style.STROKE); p.setPathEffect(null); c.drawLine(x1,y1,x2,y2,p); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); if (!visible) return;
            BallAnalyzer.Result r = latest;
            if (r == null) { p.setColor(Color.WHITE); p.setTextSize(dp(12)); c.drawText("در حال تشخیص زنده...", dp(12), getHeight()-dp(28), p); return; }
            float sx = getWidth() / (float)screenWidth, sy = getHeight() / (float)screenHeight;
            p.setColor(Color.WHITE); p.setTextSize(dp(11)); c.drawText(statusText, dp(8), getHeight()-dp(20), p);
            if (r.cue == null) return;
            float cueX=r.cue.x*sx, cueY=r.cue.y*sy;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(Color.WHITE); c.drawCircle(cueX,cueY,dp(9),p);
            BallAnalyzer.Ball target = r.target;
            if (target == null) return;
            float tx=target.x*sx, ty=target.y*sy;
            float dx=tx-cueX, dy=ty-cueY, len=(float)Math.hypot(dx,dy); if (len<1) return;
            float ux=dx/len, uy=dy/len; float contactX=tx-ux*(r.cue.r+target.r)*sx, contactY=ty-uy*(r.cue.r+target.r)*sy;
            line(c,cueX,cueY,contactX,contactY,Color.rgb(55,150,255),3);
            line(c,cueX,cueY,cueX+ux*dp(110),cueY+uy*dp(110),Color.argb(190,255,255,255),1.2f);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(Color.YELLOW); c.drawCircle(contactX,contactY,dp(7),p);
            if (r.pocketX >= 0) line(c,tx,ty,r.pocketX*sx,r.pocketY*sy,Color.rgb(255,190,45),3);
            p.setStyle(Paint.Style.FILL); p.setColor(Color.CYAN); c.drawCircle(tx,ty,dp(4),p);
        }
    }
}
