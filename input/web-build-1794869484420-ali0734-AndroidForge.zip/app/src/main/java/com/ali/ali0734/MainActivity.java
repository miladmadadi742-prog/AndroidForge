package com.ali.ali0734;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 501;
    private static final int REQ_OVERLAY = 502;
    private MediaProjectionManager projectionManager;
    private boolean pendingCapture;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        projectionManager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(20));
        root.setBackgroundColor(Color.rgb(15, 23, 32));
        TextView title = new TextView(this);
        title.setText("ali0734 • Live"); title.setTextColor(Color.WHITE);
        title.setTextSize(23); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(64)));
        TextView info = new TextView(this);
        info.setText("تشخیص زنده با مجوز ضبط صفحه اندروید\n\n۱) شروع را بزنید و اجازه Screen Capture را تأیید کنید.\n۲) به Plato برگردید؛ پنل و خطوط راهنما روی بازی نمایش داده می‌شوند.\n۳) برای توقف، از اعلان برنامه گزینه توقف را بزنید یا برنامه را باز کنید.");
        info.setTextColor(Color.LTGRAY); info.setTextSize(15); info.setGravity(Gravity.CENTER);
        info.setPadding(0, dp(14), 0, dp(24)); root.addView(info);
        Button start = new Button(this); start.setText("شروع تشخیص زنده");
        root.addView(start, new LinearLayout.LayoutParams(-1, dp(58)));
        Button stop = new Button(this); stop.setText("توقف تشخیص زنده");
        root.addView(stop, new LinearLayout.LayoutParams(-1, dp(54)));
        TextView warning = new TextView(this);
        warning.setText("تشخیص توپ‌ها آزمایشی است و ممکن است با افکت‌ها، سایه‌ها یا تغییرات میز اشتباه کند. این ابزار فقط راهنمای دیداری است و ضربه را خودکار اجرا نمی‌کند.");
        warning.setTextColor(Color.rgb(255, 190, 100)); warning.setTextSize(13);
        warning.setPadding(0, dp(20), 0, 0); root.addView(warning);
        setContentView(root);
        start.setOnClickListener(v -> beginCapture());
        stop.setOnClickListener(v -> stopService(new Intent(this, AimOverlayService.class)));
    }

    private void beginCapture() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            pendingCapture = true;
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQ_OVERLAY);
            return;
        }
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQ_OVERLAY) {
            if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
                if (pendingCapture) { pendingCapture = false; startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_CAPTURE); }
            } else Toast.makeText(this, "مجوز نمایش روی برنامه‌های دیگر لازم است", Toast.LENGTH_LONG).show();
        } else if (request == REQ_CAPTURE) {
            if (result == RESULT_OK && data != null) {
                Intent service = new Intent(this, AimOverlayService.class);
                service.putExtra(AimOverlayService.EXTRA_RESULT_CODE, result);
                service.putExtra(AimOverlayService.EXTRA_RESULT_DATA, data);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
                Toast.makeText(this, "تشخیص زنده فعال شد؛ به Plato برگردید", Toast.LENGTH_LONG).show();
            } else Toast.makeText(this, "مجوز ضبط صفحه داده نشد", Toast.LENGTH_SHORT).show();
        }
    }
}
