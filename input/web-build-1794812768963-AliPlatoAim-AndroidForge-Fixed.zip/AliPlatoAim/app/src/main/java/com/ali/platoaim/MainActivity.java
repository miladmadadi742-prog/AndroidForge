package com.ali.platoaim;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQ = 410;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);
        TextView title = new TextView(this);
        title.setText("ALI PLATO AIM\nMade by Ali\nPlato ID: _30");
        title.setTextSize(22);
        layout.addView(title);
        TextView note = new TextView(this);
        note.setText("\nFloating manual aiming guide. Move the two endpoints to line up your shot. It does not read the game or play shots automatically.");
        note.setTextSize(16);
        layout.addView(note);
        Button start = new Button(this);
        start.setText("Enable floating guide");
        layout.addView(start);
        Button stop = new Button(this);
        stop.setText("Turn off guide");
        layout.addView(stop);
        setContentView(layout);

        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, OVERLAY_REQ);
            } else startService(new Intent(this, AimOverlayService.class));
        });
        stop.setOnClickListener(v -> stopService(new Intent(this, AimOverlayService.class)));
    }
    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r,c,d);
        if (r == OVERLAY_REQ && Settings.canDrawOverlays(this))
            startService(new Intent(this, AimOverlayService.class));
    }
}
