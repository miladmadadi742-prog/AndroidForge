package com.ali.platoaim;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Floating manual aiming overlay.
 * Important: this version does not inspect Plato pixels and does not perform shots.
 */
public class AimOverlayService extends Service {
    private WindowManager wm;
    private FrameLayout root;
    private WindowManager.LayoutParams params;
    private AimView aimView;
    private TextView status;
    private boolean showTargetPath = true;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xB9151B22);

        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(dp(10), dp(8), dp(10), dp(8));
        root.addView(column, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("ALI AIM  •  راهنمای نشانه‌گیری");
        title.setTextColor(Color.WHITE);
        title.setTextSize(14);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(42), 1));
        Button close = new Button(this);
        close.setText("×");
        top.addView(close, new LinearLayout.LayoutParams(dp(48), dp(42)));
        column.addView(top);
        close.setOnClickListener(v -> stopSelf());

        status = new TextView(this);
        status.setText("دو نقطه را روی مسیر دلخواه تنظیم کن");
        status.setTextColor(0xFFE4EAF0);
        status.setTextSize(11);
        column.addView(status);

        aimView = new AimView();
        column.addView(aimView, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout controls = new LinearLayout(this);
        Button reset = new Button(this);
        reset.setText("بازنشانی");
        Button path = new Button(this);
        path.setText("مسیر هدف: روشن");
        controls.addView(reset, new LinearLayout.LayoutParams(0, dp(44), 1));
        controls.addView(path, new LinearLayout.LayoutParams(0, dp(44), 1));
        column.addView(controls);
        reset.setOnClickListener(v -> { aimView.resetPoints(); status.setText("نقاط به حالت اولیه برگشتند"); });
        path.setOnClickListener(v -> {
            showTargetPath = !showTargetPath;
            path.setText(showTargetPath ? "مسیر هدف: روشن" : "مسیر هدف: خاموش");
            aimView.invalidate();
        });

        params = new WindowManager.LayoutParams(dp(330), dp(390),
            (android.os.Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = dp(18); params.y = dp(110);
        wm.addView(root, params);

        title.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ix, iy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    sx=e.getRawX(); sy=e.getRawY(); ix=params.x; iy=params.y; return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x=ix+(int)(e.getRawX()-sx);
                    params.y=iy+(int)(e.getRawY()-sy);
                    wm.updateViewLayout(root, params); return true;
                }
                return true;
            }
        });
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    @Override public int onStartCommand(Intent i, int f, int id) { return START_STICKY; }
    @Override public void onDestroy() {
        if (root != null && root.isAttachedToWindow()) wm.removeView(root);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }

    private class AimView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private PointF cue = new PointF(.22f,.78f);
        private PointF hit = new PointF(.72f,.28f);
        private int selected = 0;
        AimView() { super(AimOverlayService.this); }

        void resetPoints() { cue.set(.22f,.78f); hit.set(.72f,.28f); invalidate(); }
        private float px(float x) { return x * getWidth(); }
        private float py(float y) { return y * getHeight(); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            RectF table=new RectF(14,14,w-14,h-14);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF087B3B);
            c.drawRoundRect(table,18,18,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(0xFF8B542D);
            c.drawRoundRect(table,18,18,p);
            p.setStrokeWidth(1); p.setColor(0x667FFFFFFF);
            c.drawLine(table.left, h/2, table.right, h/2, p);
            float[][] pockets={{table.left,table.top},{w/2,table.top},{table.right,table.top},
                               {table.left,table.bottom},{w/2,table.bottom},{table.right,table.bottom}};
            p.setStyle(Paint.Style.FILL); p.setColor(Color.BLACK);
            for(float[] q:pockets) c.drawCircle(q[0],q[1],10,p);

            float ax=px(cue.x), ay=py(cue.y), bx=px(hit.x), by=py(hit.y);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(0xFFFFE45C);
            c.drawLine(ax,ay,bx,by,p);
            if(showTargetPath) {
                float dx=bx-ax, dy=by-ay, len=(float)Math.hypot(dx,dy);
                if(len>1) {
                    float ex=bx+(dx/len)*Math.min(w*.30f,90);
                    float ey=by+(dy/len)*Math.min(h*.30f,90);
                    p.setColor(0xFF55D9FF); p.setStrokeWidth(2);
                    c.drawLine(bx,by,ex,ey,p);
                }
            }
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.WHITE); c.drawCircle(ax,ay,10,p);
            p.setColor(0xFFFF5252); c.drawCircle(bx,by,10,p);
            p.setColor(Color.WHITE); p.setTextSize(11);
            c.drawText("سفید",ax+12,ay-10,p);
            c.drawText("هدف",bx+12,by-10,p);
            p.setTextSize(10); p.setColor(0xCCFFFFFF);
            c.drawText("نقطه سفید و قرمز را بکش",16,h-10,p);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float x=e.getX()/Math.max(1,getWidth()), y=e.getY()/Math.max(1,getHeight());
            if(e.getAction()==MotionEvent.ACTION_DOWN) {
                selected = Math.hypot(e.getX()-px(cue.x),e.getY()-py(cue.y)) <
                           Math.hypot(e.getX()-px(hit.x),e.getY()-py(hit.y)) ? 1 : 2;
                return true;
            }
            if(e.getAction()==MotionEvent.ACTION_MOVE) {
                x=Math.max(.04f,Math.min(.96f,x)); y=Math.max(.04f,Math.min(.96f,y));
                if(selected==1) cue.set(x,y); else hit.set(x,y);
                invalidate(); return true;
            }
            return true;
        }
    }
}
