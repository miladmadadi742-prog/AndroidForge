package com.ali.platoaim;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 410;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(24), dp(36), dp(24), dp(24));
        page.setBackgroundColor(0xFF101820);

        TextView title = new TextView(this);
        title.setText("ALI PLATO AIM\nراهنمای شناور نشانه‌گیری");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, dp(110)));

        TextView info = new TextView(this);
        info.setText("پنل تمرینی شناور برای تنظیم دستی مسیر توپ. برای نمایش روی بازی، مجوز «نمایش روی برنامه‌های دیگر» را فعال کن.");
        info.setTextColor(0xFFD5DDE5);
        info.setTextSize(16);
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(-1, dp(130));
        infoParams.bottomMargin = dp(20);
        page.addView(info, infoParams);

        Button start = new Button(this);
        start.setText("فعال‌کردن پنل شناور");
        page.addView(start, new LinearLayout.LayoutParams(-1, dp(56)));

        Button stop = new Button(this);
        stop.setText("خاموش‌کردن پنل");
        LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(-1, dp(56));
        stopParams.topMargin = dp(12);
        page.addView(stop, stopParams);

        setContentView(page);

        start.setOnClickListener(v -> enableOverlay());
        stop.setOnClickListener(v -> stopService(new Intent(this, AimOverlayService.class)));
    }

    private void enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(permission, OVERLAY_REQUEST);
        } else {
            startService(new Intent(this, AimOverlayService.class));
        }
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == OVERLAY_REQUEST && Settings.canDrawOverlays(this)) {
            startService(new Intent(this, AimOverlayService.class));
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
