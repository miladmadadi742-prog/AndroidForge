package com.ali.platoaim;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AimOverlayService extends Service {
    private WindowManager windowManager;
    private FrameLayout panel;
    private WindowManager.LayoutParams panelParams;
    private AimCanvas aimCanvas;
    private boolean extendedLine = true;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        panel = new FrameLayout(this);
        panel.setBackgroundColor(0xE91B2530);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), dp(8), dp(10), dp(10));
        panel.addView(content, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = new TextView(this);
        heading.setText("ALI AIM  •  راهنمای نشانه‌گیری");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(14);
        header.addView(heading, new LinearLayout.LayoutParams(0, dp(44), 1));

        Button close = new Button(this);
        close.setText("×");
        header.addView(close, new LinearLayout.LayoutParams(dp(48), dp(44)));
        content.addView(header);
        close.setOnClickListener(v -> stopSelf());

        TextView hint = new TextView(this);
        hint.setText("نقطه سفید و قرمز را با انگشت جابه‌جا کن");
        hint.setTextColor(0xFFE0E7EF);
        hint.setTextSize(12);
        content.addView(hint);

        aimCanvas = new AimCanvas();
        LinearLayout.LayoutParams canvasParams = new LinearLayout.LayoutParams(-1, 0, 1);
        canvasParams.topMargin = dp(8);
        canvasParams.bottomMargin = dp(8);
        content.addView(aimCanvas, canvasParams);

        LinearLayout actions = new LinearLayout(this);
        Button reset = new Button(this);
        reset.setText("بازنشانی");
        Button line = new Button(this);
        line.setText("امتداد: روشن");
        actions.addView(reset, new LinearLayout.LayoutParams(0, dp(46), 1));
        actions.addView(line, new LinearLayout.LayoutParams(0, dp(46), 1));
        content.addView(actions);

        reset.setOnClickListener(v -> aimCanvas.reset());
        line.setOnClickListener(v -> {
            extendedLine = !extendedLine;
            line.setText(extendedLine ? "امتداد: روشن" : "امتداد: خاموش");
            aimCanvas.invalidate();
        });

        int windowType = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        panelParams = new WindowManager.LayoutParams(
                dp(320), dp(390), windowType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                android.graphics.PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = dp(16);
        panelParams.y = dp(100);

        try {
            windowManager.addView(panel, panelParams);
        } catch (RuntimeException error) {
            stopSelf();
            return;
        }

        header.setOnTouchListener(new View.OnTouchListener() {
            private float startX, startY;
            private int initialX, initialY;

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = event.getRawX();
                    startY = event.getRawY();
                    initialX = panelParams.x;
                    initialY = panelParams.y;
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    panelParams.x = initialX + (int) (event.getRawX() - startX);
                    panelParams.y = initialY + (int) (event.getRawY() - startY);
                    try {
                        windowManager.updateViewLayout(panel, panelParams);
                    } catch (RuntimeException ignored) { }
                    return true;
                }
                return event.getAction() == MotionEvent.ACTION_UP;
            }
        });
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        if (panel != null && panel.getParent() != null) {
            try {
                windowManager.removeView(panel);
            } catch (RuntimeException ignored) { }
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private class AimCanvas extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final PointF whiteBall = new PointF(0.22f, 0.76f);
        private final PointF targetBall = new PointF(0.72f, 0.28f);
        private int selectedPoint;

        AimCanvas() {
            super(AimOverlayService.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        void reset() {
            whiteBall.set(0.22f, 0.76f);
            targetBall.set(0.72f, 0.28f);
            invalidate();
        }

        private float x(float fraction) { return fraction * getWidth(); }
        private float y(float fraction) { return fraction * getHeight(); }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float width = getWidth();
            float height = getHeight();
            if (width <= 0 || height <= 0) return;

            RectF table = new RectF(dp(12), dp(12), width - dp(12), height - dp(12));
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xFF087A42);
            canvas.drawRoundRect(table, dp(14), dp(14), paint);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(5));
            paint.setColor(0xFF9B6338);
            canvas.drawRoundRect(table, dp(14), dp(14), paint);

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.BLACK);
            float[][] holes = {
                    {table.left, table.top}, {width / 2, table.top}, {table.right, table.top},
                    {table.left, table.bottom}, {width / 2, table.bottom}, {table.right, table.bottom}
            };
            for (float[] hole : holes) canvas.drawCircle(hole[0], hole[1], dp(8), paint);

            float ax = x(whiteBall.x), ay = y(whiteBall.y);
            float bx = x(targetBall.x), by = y(targetBall.y);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(0xFFFFE36A);
            canvas.drawLine(ax, ay, bx, by, paint);

            if (extendedLine) {
                float dx = bx - ax, dy = by - ay;
                float length = (float) Math.hypot(dx, dy);
                if (length > 1) {
                    float extension = Math.min(dp(90), width * 0.30f);
                    paint.setColor(0xFF55D9FF);
                    canvas.drawLine(bx, by, bx + dx / length * extension,
                            by + dy / length * extension, paint);
                }
            }

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            canvas.drawCircle(ax, ay, dp(9), paint);
            paint.setColor(0xFFFF5555);
            canvas.drawCircle(bx, by, dp(9), paint);
            paint.setTextSize(dp(11));
            paint.setColor(Color.WHITE);
            canvas.drawText("سفید", ax + dp(12), ay - dp(10), paint);
            canvas.drawText("هدف", bx + dp(12), by - dp(10), paint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            float px = event.getX();
            float py = event.getY();
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                float da = (float) Math.hypot(px - x(whiteBall.x), py - y(whiteBall.y));
                float db = (float) Math.hypot(px - x(targetBall.x), py - y(targetBall.y));
                selectedPoint = da <= db ? 1 : 2;
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                float nx = Math.max(0.06f, Math.min(0.94f, px / Math.max(1, getWidth())));
                float ny = Math.max(0.06f, Math.min(0.94f, py / Math.max(1, getHeight())));
                if (selectedPoint == 1) whiteBall.set(nx, ny);
                else targetBall.set(nx, ny);
                invalidate();
                return true;
            }
            return event.getAction() == MotionEvent.ACTION_UP
                    || event.getAction() == MotionEvent.ACTION_CANCEL;
        }
    }
}
