package com.example.trickshotassistant

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.*

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: FrameLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlay != null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = FrameLayout(this)
        val guide = GuideView(this)
        root.addView(guide, FrameLayout.LayoutParams(320, 260))

        val controls = TextView(this).apply {
            text = "🎱 راهنما  •  جابه‌جا کن\nبرای چرخش خط، لمس و کشیدن"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(18, 12, 18, 12)
            setBackgroundColor(0xCC202020.toInt())
            setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f; var downY = 0f
                var startX = 0; var startY = 0
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    val lp = root.layoutParams as WindowManager.LayoutParams
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> {
                            downX = e.rawX; downY = e.rawY
                            startX = lp.x; startY = lp.y
                            return true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            lp.x = startX + (e.rawX - downX).toInt()
                            lp.y = startY + (e.rawY - downY).toInt()
                            wm.updateViewLayout(root, lp)
                            return true
                        }
                    }
                    return true
                }
            })
        }
        root.addView(controls, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 70; y = 240 }
        wm.addView(root, lp)
        overlay = root
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        overlay?.let { wm.removeView(it) }
        overlay = null
        super.onDestroy()
    }

    private class GuideView(ctx: android.content.Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.YELLOW; strokeWidth = 5f; style = Paint.Style.STROKE
        }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.RED; style = Paint.Style.FILL
        }
        private var angle = -25f
        private var lastX = 0f
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val cx = width / 2f; val cy = height / 2f
            val r = min(width, height) * .43f
            val a = Math.toRadians(angle.toDouble())
            c.drawLine(cx - cos(a).toFloat()*r, cy - sin(a).toFloat()*r,
                cx + cos(a).toFloat()*r, cy + sin(a).toFloat()*r, p)
            c.drawCircle(cx, cy, 9f, dot)
            p.color = Color.CYAN
            c.drawCircle(cx, cy, 24f, p)
            p.color = Color.YELLOW
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { lastX = e.x; return true }
                MotionEvent.ACTION_MOVE -> {
                    angle += (e.x - lastX) * .5f
                    lastX = e.x
                    invalidate()
                    return true
                }
            }
            return true
        }
    }
}
