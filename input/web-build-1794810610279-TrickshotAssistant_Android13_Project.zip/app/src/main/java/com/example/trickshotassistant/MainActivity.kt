package com.example.trickshotassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.WHITE)
        }
        val title = TextView(this).apply {
            text = "Trickshot Assistant"
            textSize = 24f
            setTextColor(Color.BLACK)
        }
        val info = TextView(this).apply {
            text = "\nابزار راهنمای نشانه‌گیری شناور\n\nاین نسخه خطوط راهنما را به‌صورت دستی روی بازی قرار می‌دهد؛ توپ‌ها را خودکار تشخیص نمی‌دهد و ضربه‌ای هم اجرا نمی‌کند."
            textSize = 16f
            setTextColor(Color.DKGRAY)
        }
        val permission = Button(this).apply { text = "فعال‌کردن مجوز نمایش روی برنامه‌ها" }
        val start = Button(this).apply { text = "نمایش ابزار شناور" }
        val stop = Button(this).apply { text = "بستن ابزار شناور" }

        permission.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        }
        start.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, OverlayService::class.java))
            } else {
                permission.performClick()
            }
        }
        stop.setOnClickListener { stopService(Intent(this, OverlayService::class.java)) }

        layout.addView(title); layout.addView(info)
        layout.addView(permission); layout.addView(start); layout.addView(stop)
        setContentView(layout)
    }
}
