package com.ali.platoaim;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

public class AimOverlayService extends Service {
    private WindowManager wm;
    private FrameLayout panel;
    private WindowManager.LayoutParams params;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        panel = new FrameLayout(this);
        AimView aim = new AimView();
        panel.addView(aim, new FrameLayout.LayoutParams(520, 420));
        TextView label = new TextView(this);
        label.setText("ALI AIM  •  drag endpoints  •  × close");
        label.setTextColor(Color.WHITE);
        label.setTextSize(12);
        label.setBackgroundColor(0xCC202020);
        label.setPadding(12, 8, 12, 8);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP|Gravity.LEFT);
        panel.addView(label, lp);
        label.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ix, iy;
            public boolean onTouch(View v, MotionEvent e) {
                if(e.getAction()==MotionEvent.ACTION_DOWN){ sx=e.getRawX(); sy=e.getRawY(); ix=params.x; iy=params.y; return true; }
                if(e.getAction()==MotionEvent.ACTION_MOVE){ params.x=ix+(int)(e.getRawX()-sx); params.y=iy+(int)(e.getRawY()-sy); wm.updateViewLayout(panel,params); return true; }
                return true;
            }
        });
        label.setOnClickListener(v -> stopSelf());
        params = new WindowManager.LayoutParams(520, 420,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP|Gravity.LEFT;
        params.x = 80; params.y = 180;
        wm.addView(panel, params);
    }

    @Override public int onStartCommand(Intent i, int f, int id) { return START_STICKY; }
    @Override public void onDestroy() { if(panel!=null && panel.isAttachedToWindow()) wm.removeView(panel); super.onDestroy(); }
    @Override public IBinder onBind(Intent i) { return null; }

    private class AimView extends View {
        Paint p = new Paint(3);
        PointF a = new PointF(90,300), b = new PointF(420,100);
        int selected = 0;
        AimView(){ super(AimOverlayService.this); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            p.setColor(0x55333333); p.setStyle(Paint.Style.FILL);
            c.drawRoundRect(new RectF(4,4,getWidth()-4,getHeight()-4),18,18,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(Color.WHITE);
            c.drawRoundRect(new RectF(8,8,getWidth()-8,getHeight()-8),14,14,p);
            p.setColor(0xFF00E5FF); p.setStrokeWidth(4); c.drawLine(a.x,a.y,b.x,b.y,p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFD54F); c.drawCircle(a.x,a.y,13,p);
            p.setColor(0xFFFF5252); c.drawCircle(b.x,b.y,13,p);
            p.setColor(Color.WHITE); p.setTextSize(22); c.drawText("Drag yellow / red points to align",18,395,p);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            float x=e.getX(), y=e.getY();
            if(e.getAction()==MotionEvent.ACTION_DOWN) {
                selected = Math.hypot(x-a.x,y-a.y) < Math.hypot(x-b.x,y-b.y) ? 1 : 2;
                return true;
            }
            if(e.getAction()==MotionEvent.ACTION_MOVE) {
                if(selected==1){a.set(x,y);} else {b.set(x,y);}
                invalidate(); return true;
            }
            return true;
        }
    }
}
