package com.ali.platoaim;
import android.content.Context;import android.graphics.*;import android.view.View;import java.util.*;

public class AnalysisView extends View {
 private Bitmap bitmap; private BallAnalyzer.Result result; private Paint p=new Paint(3);
 public AnalysisView(Context c,Bitmap b,BallAnalyzer.Result r){super(c);bitmap=b;result=r;}
 @Override protected void onDraw(Canvas c){super.onDraw(c);if(bitmap==null)return;float scale=Math.min(getWidth()/(float)bitmap.getWidth(),getHeight()/(float)bitmap.getHeight());float ox=(getWidth()-bitmap.getWidth()*scale)/2,oy=(getHeight()-bitmap.getHeight()*scale)/2;c.save();c.translate(ox,oy);c.scale(scale,scale);c.drawBitmap(bitmap,0,0,null);
  if(result!=null){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.5f/scale);p.setColor(Color.YELLOW);c.drawRect(result.left,result.top,result.right,result.bottom,p);
   for(BallAnalyzer.Ball b:result.balls){p.setColor(b.cue?Color.WHITE:Color.CYAN);p.setStrokeWidth(2.5f/scale);c.drawCircle(b.x,b.y,b.r+2/scale,p);}
   if(result.cue!=null){BallAnalyzer.Ball cue=result.cue;float best=Float.MAX_VALUE;BallAnalyzer.Ball target=null;for(BallAnalyzer.Ball b:result.balls)if(!b.cue){float d=(b.x-cue.x)*(b.x-cue.x)+(b.y-cue.y)*(b.y-cue.y);if(d<best){best=d;target=b;}}
    if(target!=null){
      // Six approximate pocket centers based on the detected cloth rectangle.
      float[][] pockets={{result.left,result.top},{(result.left+result.right)/2f,result.top},{result.right,result.top},{result.left,result.bottom},{(result.left+result.right)/2f,result.bottom},{result.right,result.bottom}};
      float bestPocket=Float.MAX_VALUE,px=0,py=0;for(float[] pocket:pockets){float dd=(pocket[0]-target.x)*(pocket[0]-target.x)+(pocket[1]-target.y)*(pocket[1]-target.y);if(dd<bestPocket){bestPocket=dd;px=pocket[0];py=pocket[1];}}
      float dx=px-target.x,dy=py-target.y,len=(float)Math.sqrt(dx*dx+dy*dy);if(len>0){dx/=len;dy/=len;
       // Object-ball route toward the nearest pocket, plus an estimated ghost-ball contact point.
       p.setColor(Color.YELLOW);p.setStrokeWidth(4/scale);c.drawLine(target.x,target.y,px,py,p);
       float contactX=target.x-dx*(cue.r+target.r),contactY=target.y-dy*(cue.r+target.r);
       p.setColor(Color.CYAN);p.setStrokeWidth(3/scale);c.drawLine(cue.x,cue.y,contactX,contactY,p);
       p.setColor(Color.RED);p.setStyle(Paint.Style.STROKE);c.drawCircle(target.x,target.y,target.r+5/scale,p);
       p.setColor(Color.WHITE);c.drawCircle(px,py,Math.max(5/scale,target.r*.55f),p);
      }
     }
   }
  }c.restore();}
}
