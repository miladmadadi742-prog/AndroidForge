package com.ali.platoaim;

import android.graphics.Bitmap;
import android.graphics.Color;
import java.util.*;

/** Fast heuristic detector for live screen frames. Coordinates are source-frame pixels. */
public final class BallAnalyzer {
    public static final class Ball { public float x,y,r; public int color; public boolean cue; Ball(float x,float y,float r,int c,boolean q){this.x=x;this.y=y;this.r=r;color=c;cue=q;} }
    public static final class Result {
        public final ArrayList<Ball> balls = new ArrayList<>();
        public Ball cue, target; public float left,top,right,bottom; public float pocketX=-1,pocketY=-1; public String note="";
        public void scaleCoordinates(float s) { for (Ball b:balls) { b.x*=s; b.y*=s; b.r*=s; } left*=s; top*=s; right*=s; bottom*=s; if(pocketX>=0){pocketX*=s;pocketY*=s;} }
    }
    private BallAnalyzer() {}
    public static Result analyze(Bitmap src) {
        Result out=new Result(); int w=src.getWidth(),h=src.getHeight(); int[] px=new int[w*h]; src.getPixels(px,0,w,0,0,w,h);
        int minX=w,minY=h,maxX=0,maxY=0,count=0;
        // Green felt region; sample every second pixel to reduce work.
        for(int y=0;y<h;y+=2) for(int x=0;x<w;x+=2){int c=px[y*w+x];int r=Color.red(c),g=Color.green(c),b=Color.blue(c);if(g>65&&g>r*1.14&&g>b*1.07&&g-r>20){minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);count++;}}
        if(count<80||maxX-minX<w*.18||maxY-minY<h*.12){out.note="میز پیدا نشد؛ میز باید روی صفحه دیده شود";return out;}
        // Tighten the cloth rectangle away from wooden rails.
        int padX=Math.max(2,(maxX-minX)/35),padY=Math.max(2,(maxY-minY)/35);
        out.left=minX+padX;out.right=maxX-padX;out.top=minY+padY;out.bottom=maxY-padY;
        int x0=Math.max(0,(int)out.left),x1=Math.min(w-1,(int)out.right),y0=Math.max(0,(int)out.top),y1=Math.min(h-1,(int)out.bottom);
        boolean[] seen=new boolean[w*h]; int[] queue=new int[w*h];
        for(int y=y0;y<=y1;y++) for(int x=x0;x<=x1;x++){
            int idx=y*w+x;if(seen[idx]||!candidate(px[idx]))continue;
            int head=0,tail=0;queue[tail++]=idx;seen[idx]=true;long sx=0,sy=0,rr=0,gg=0,bb=0;int n=0,bx0=x,bx1=x,by0=y,by1=y;
            while(head<tail){int q=queue[head++],qx=q%w,qy=q/w,c=px[q];sx+=qx;sy+=qy;n++;rr+=Color.red(c);gg+=Color.green(c);bb+=Color.blue(c);bx0=Math.min(bx0,qx);bx1=Math.max(bx1,qx);by0=Math.min(by0,qy);by1=Math.max(by1,qy);
                int[] ns={q-1,q+1,q-w,q+w};for(int z:ns){if(z<0||z>=w*h)continue;int nx=z%w,ny=z/w;if(Math.abs(nx-qx)+Math.abs(ny-qy)!=1||nx<x0||nx>x1||ny<y0||ny>y1||seen[z]||!candidate(px[z]))continue;seen[z]=true;queue[tail++]=z;}}
            int bw=bx1-bx0+1,bh=by1-by0+1;if(n<8||n>1200||bw<5||bh<5||bw>52||bh>52||Math.max(bw,bh)>Math.min(bw,bh)*1.8)continue;
            float cx=sx/(float)n,cy=sy/(float)n,rad=(bw+bh)*.25f;int avg=Color.rgb((int)(rr/n),(int)(gg/n),(int)(bb/n));
            boolean white=Color.red(avg)>150&&Color.green(avg)>150&&Color.blue(avg)>140&&Math.max(Color.red(avg),Math.max(Color.green(avg),Color.blue(avg)))-Math.min(Color.red(avg),Math.min(Color.green(avg),Color.blue(avg)))<100;
            Ball ball=new Ball(cx,cy,rad,avg,white);out.balls.add(ball);
        }
        // Cue ball is the brightest near-neutral ball; do not assume it is leftmost.
        float bestWhite=-1;for(Ball b:out.balls)if(b.cue){float score=Color.red(b.color)+Color.green(b.color)+Color.blue(b.color);if(score>bestWhite){bestWhite=score;out.cue=b;}}
        if(out.cue!=null){float best=Float.MAX_VALUE;for(Ball b:out.balls){if(b==out.cue)continue;float d=(float)Math.hypot(b.x-out.cue.x,b.y-out.cue.y);if(d<best){best=d;out.target=b;}}}
        if(out.target!=null) choosePocket(out,out.target);
        out.note="توپ‌ها: "+out.balls.size()+" | "+(out.cue==null?"توپ سفید پیدا نشد":"توپ سفید پیدا شد");
        return out;
    }
    private static void choosePocket(Result r,Ball target){
        float[][] pockets={{r.left,r.top},{(r.left+r.right)/2,r.top},{r.right,r.top},{r.left,r.bottom},{(r.left+r.right)/2,r.bottom},{r.right,r.bottom}};
        // Choose the pocket most aligned with the incoming cue-to-object direction.
        float dx=target.x-r.cue.x,dy=target.y-r.cue.y,dl=(float)Math.hypot(dx,dy);if(dl<1)return;dx/=dl;dy/=dl;
        float best=Float.MAX_VALUE;for(float[] p:pockets){float vx=p[0]-target.x,vy=p[1]-target.y,d=(float)Math.hypot(vx,vy);if(d<1)continue;float dot=(dx*vx+dy*vy)/d;float score=d*(1.0f+2.5f*(1-dot));if(score<best){best=score;r.pocketX=p[0];r.pocketY=p[1];}}
    }
    private static boolean candidate(int c){int r=Color.red(c),g=Color.green(c),b=Color.blue(c),max=Math.max(r,Math.max(g,b)),min=Math.min(r,Math.min(g,b));boolean vivid=max>105&&max-min>38&&!(g>r*1.12&&g>b*1.08);boolean white=min>170&&max-min<80;return vivid||white;}
}
