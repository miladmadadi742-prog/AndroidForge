package com.example.platoliveanalyzer

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import kotlin.math.*

class CaptureService : Service() {
    private var projection: MediaProjection?=null
    private var reader: ImageReader?=null
    private var display: VirtualDisplay?=null
    private var busy=false
    private val handler=Handler(Looper.getMainLooper())
    override fun onBind(intent: Intent?)=null
    override fun onStartCommand(intent: Intent?, flags:Int, startId:Int):Int {
        if (intent?.action=="STOP") { stopSelf(); return START_NOT_STICKY }
        val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel("capture","Live analysis",NotificationManager.IMPORTANCE_LOW))
        val notification=if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,"capture") else Notification.Builder(this)
        startForeground(7, notification.setContentTitle("Plato Live Analyzer").setContentText("در حال تحلیل تصویر صفحه").setSmallIcon(android.R.drawable.ic_menu_view).build())
        val code=intent?.getIntExtra("code",0) ?: 0
        val data=intent?.parcelable<Intent>("data") ?: return START_NOT_STICKY
        val dm=resources.displayMetrics
        val w=dm.widthPixels; val h=dm.heightPixels; val density=dm.densityDpi
        projection=(getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(code,data)
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2)
        display=projection?.createVirtualDisplay("PlatoAnalyzer",w,h,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader?.surface,null,handler)
        reader?.setOnImageAvailableListener({ r ->
            val image=try { r.acquireLatestImage() } catch (_:Exception) { null } ?: return@setOnImageAvailableListener
            if(!busy) {
                busy=true
                try {
                    val balls=BallDetector.detect(image)
                    OverlayService.update(balls,w,h)
                } catch (_:Exception) { } finally { busy=false; image.close() }
            } else image.close()
        },handler)
        return START_STICKY
    }
    override fun onDestroy() { reader?.setOnImageAvailableListener(null,null); display?.release(); reader?.close(); projection?.stop(); stopForeground(STOP_FOREGROUND_REMOVE); super.onDestroy() }
    private inline fun <reified T:android.os.Parcelable> Intent.parcelable(key:String):T? =
        if(Build.VERSION.SDK_INT>=33) getParcelableExtra(key,T::class.java) else @Suppress("DEPRECATION") (getParcelableExtra(key) as? T)
}

data class Ball(val x:Float,val y:Float,val color:Int,val radius:Float)
object BallDetector {
    // Lightweight color-component detector; coordinates are normalized to screen dimensions.
    fun detect(im:Image):List<Ball> {
        val p=im.planes[0]; val b=p.buffer
        val w=im.width; val h=im.height; val row=p.rowStride; val pix=p.pixelStride
        val step=3; val sw=w/step; val sh=h/step
        val mask=BooleanArray(sw*sh)
        fun rgba(x:Int,y:Int):Int { val i=y*row+x*pix; val r=b.get(i).toInt() and 255; val g=b.get(i+1).toInt() and 255; val bl=b.get(i+2).toInt() and 255; return Color.rgb(r,g,bl) }
        for(y in 0 until sh) for(x in 0 until sw) {
            val c=rgba(x*step,y*step); val hsv=FloatArray(3); Color.colorToHSV(c,hsv)
            mask[y*sw+x]=(hsv[1]>.38f && hsv[2]>.42f) || (hsv[1]<.18f && hsv[2]>.78f)
        }
        val seen=BooleanArray(mask.size); val out=ArrayList<Ball>(); val qx=IntArray(mask.size); val qy=IntArray(mask.size)
        for(y in 1 until sh-1) for(x in 1 until sw-1) {
            val start=y*sw+x
            if(!mask[start] || seen[start]) continue
            var head=0; var tail=0; qx[tail]=x; qy[tail++]=y; seen[start]=true
            var sx=0; var sy=0; var count=0; var minx=x; var maxx=x; var miny=y; var maxy=y
            while(head<tail && count<2500) {
                val xx=qx[head]; val yy=qy[head++]; sx+=xx; sy+=yy; count++
                minx=min(minx,xx); maxx=max(maxx,xx); miny=min(miny,yy); maxy=max(maxy,yy)
                for(d in intArrayOf(-1,1,-sw,sw)) { val ni=yy*sw+xx+d; if(ni in mask.indices && mask[ni] && !seen[ni]) { seen[ni]=true; qx[tail]=ni%sw; qy[tail++]=ni/sw } }
            }
            val bw=maxx-minx+1; val bh=maxy-miny+1
            if(count in 8..500 && bw in 3..22 && bh in 3..22 && max(bw,bh).toFloat()/max(1,min(bw,bh))<1.7f) {
                val cx=sx.toFloat()/count*step/w; val cy=sy.toFloat()/count*step/h
                val col=rgba((sx/count*step).coerceIn(0,w-1),(sy/count*step).coerceIn(0,h-1))
                out.add(Ball(cx,cy,col,max(bw,bh)*step.toFloat()/2/max(w,h)))
            }
        }
        return out.take(24)
    }
}
