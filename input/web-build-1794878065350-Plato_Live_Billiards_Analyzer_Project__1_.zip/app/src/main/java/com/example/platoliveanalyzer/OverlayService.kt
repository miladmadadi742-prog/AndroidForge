package com.example.platoliveanalyzer

import android.app.Service
import android.content.Intent
import android.graphics.*
import android.os.IBinder
import android.view.*
import kotlin.math.*

class OverlayService:Service() {
    companion object {
        @Volatile private var latest:List<Ball> = emptyList()
        @Volatile private var screenW=1; @Volatile private var screenH=1
        fun update(b:List<Ball>,w:Int,h:Int) { latest=b; screenW=w; screenH=h }
    }
    private var wm:WindowManager?=null; private var view:GuideView?=null
    override fun onBind(i:Intent?):IBinder?=null
    override fun onCreate() {
        super.onCreate(); wm=getSystemService(WINDOW_SERVICE) as WindowManager
        view=GuideView()
        val type=if(android.os.Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp=WindowManager.LayoutParams(-1,-1,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT)
        wm?.addView(view,lp)
    }
    override fun onStartCommand(i:Intent?,f:Int,s:Int):Int { view?.invalidate(); return START_STICKY }
    override fun onDestroy(){ try{wm?.removeView(view)}catch(_:Exception){}; super.onDestroy() }
    inner class GuideView:View(this@OverlayService) {
        private val p=Paint(3)
        override fun onDraw(c:Canvas) {
            super.onDraw(c); val balls=latest
            p.style=Paint.Style.STROKE; p.strokeWidth=3f
            balls.forEach { ball ->
                val x=ball.x*width; val y=ball.y*height
                p.color=ball.color; c.drawCircle(x,y,max(8f,ball.radius*max(width,height)),p)
            }
            // Display a conservative guide from the brightest likely cue ball to nearest detected object.
            val cue=balls.filter { ColorUtilsLite.isWhite(it.color) }.minByOrNull { it.radius }
            if(cue!=null && balls.size>1) {
                val target=balls.filter { it!==cue }.minByOrNull { hypot((it.x-cue.x).toDouble(),(it.y-cue.y).toDouble()) }
                if(target!=null) {
                    p.color=Color.CYAN; p.strokeWidth=4f
                    c.drawLine(cue.x*width,cue.y*height,target.x*width,target.y*height,p)
                    val dx=target.x-cue.x; val dy=target.y-cue.y
                    c.drawLine(target.x*width,target.y*height,(target.x+dx*.7f)*width,(target.y+dy*.7f)*height,p)
                }
            }
            postInvalidateDelayed(120)
        }
    }
}
object ColorUtilsLite { fun isWhite(c:Int)= (Color.red(c)+Color.green(c)+Color.blue(c))/3>205 && max(Color.red(c),max(Color.green(c),Color.blue(c)))-min(Color.red(c),min(Color.green(c),Color.blue(c)))<55 }
