package com.example.platoliveanalyzer

import android.app.*
import android.content.*
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private val capture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK && r.data != null) {
            val i = Intent(this, CaptureService::class.java).apply {
                putExtra("code", r.resultCode); putExtra("data", r.data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            status.text = "تحلیل زنده فعال شد؛ بازی را باز کنید."
        } else status.text = "مجوز ضبط صفحه داده نشد."
    }
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,36,28,24) }
        layout.addView(TextView(this).apply { text="Plato Live Billiards Analyzer"; textSize=22f })
        layout.addView(TextView(this).apply { text="تحلیل تصویری مستقل؛ بدون لمس، هدف‌گیری یا ضربه‌زدن خودکار در بازی." ; textSize=15f; setPadding(0,18,0,18) })
        val overlay = Button(this).apply { text="۱) فعال‌کردن پنجره شناور" ; setOnClickListener {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else { startService(Intent(this@MainActivity, OverlayService::class.java)); status.text="مجوز پنجره شناور فعال است." }
        } }
        layout.addView(overlay)
        layout.addView(Button(this).apply { text="۲) شروع دریافت زنده تصویر صفحه"; setOnClickListener {
            if (!Settings.canDrawOverlays(this@MainActivity)) { status.text="ابتدا مجوز پنجره شناور را فعال کنید."; return@setOnClickListener }
            val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            capture.launch(mgr.createScreenCaptureIntent())
        }})
        layout.addView(Button(this).apply { text="توقف تحلیل"; setOnClickListener { stopService(Intent(this@MainActivity,CaptureService::class.java)); status.text="تحلیل متوقف شد." } })
        status=TextView(this).apply { text="آماده"; textSize=15f; setPadding(0,24,0,0) }; layout.addView(status)
        setContentView(layout)
    }
}
